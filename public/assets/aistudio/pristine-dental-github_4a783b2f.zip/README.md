# Dr. Parikh's Pristine Dental Clinic — Website

Static website: HTML, CSS and vanilla JavaScript. No build step, no database, no API keys.

## Files
| File | What it is |
|---|---|
| `index.html` | All page content, SEO tags and DentalClinic schema |
| `styles.css` | Design system, layout, animations, responsive rules |
| `script.js` | Intro, hero slideshow, menu, treatment filters and modals, FAQs, reviews, booking form |
| `assets/` | Logo and all photos (WebP) |
| `.nojekyll` | Tells GitHub Pages to serve the files as-is |

## Publish with GitHub Pages
1. Create a new **public** repository on GitHub (no README, no .gitignore).
2. Upload every file and the `assets` folder to the repository.
3. Go to **Settings → Pages**.
4. Under **Source** choose **Deploy from a branch**, branch **main**, folder **/ (root)**, then **Save**.
5. Wait 1–2 minutes. The site appears at `https://<username>.github.io/<repo>/`.

## Use pristinedental.in instead
1. In **Settings → Pages → Custom domain**, enter `pristinedental.in` and save. This creates a `CNAME` file in the repository.
2. At your domain registrar, add these DNS records:
   - Four `A` records for `@`: `185.199.108.153`, `185.199.109.153`, `185.199.110.153`, `185.199.111.153`
   - One `CNAME` record for `www` pointing to `<username>.github.io`
3. Back in Settings → Pages, tick **Enforce HTTPS** once the certificate is issued (can take up to an hour).

## Booking form
Name and mobile number are required. On submit, WhatsApp opens to +91 99093 36825 with the details filled in. Nothing is stored on the website.

## Update before publishing (search `DEV NOTE` in index.html)
- Dr. Parikh's verified qualifications
- Verified clinic timings (Contact section and the schema)
- The clinic's direct Google review link
- Confirm the digital-scanning wording with the clinic
- Replace the hero slide with the Freepik watermark, or remove that slide
